#!/bin/sh
/opt/muos/device/current/script/led_control.sh 6 10 10
